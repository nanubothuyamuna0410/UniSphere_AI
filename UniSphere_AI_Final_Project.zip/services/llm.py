from ollama import chat
from config import OLLAMA_MODEL

def generate_answer(question, context):
    prompt = f"""
You are UniSphere AI, a university information assistant.

Answer ONLY using the supplied university document context.
Do not invent, guess, or assume information.
If the answer is not present, say:
"I could not find this information in the available university documents."
Give a clear and concise answer.

University Document Context:
{context}

Student Question:
{question}

Answer:
"""
    response = chat(
        model=OLLAMA_MODEL,
        messages=[{"role": "user", "content": prompt}]
    )
    return response["message"]["content"]
