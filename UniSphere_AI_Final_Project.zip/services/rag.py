from services.embeddings import create_embeddings
from services.vector_score import search_documents
from services.llm import generate_answer

def answer_question(question, n_results=3):
    question_embedding = create_embeddings([question])[0]
    results = search_documents(question_embedding, n_results=n_results)
    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    answer = generate_answer(question, "\n\n".join(documents))
    return {"answer": answer, "documents": documents, "metadatas": metadatas}
