import chromadb
import uuid

client = chromadb.PersistentClient(path="chroma_db")
collection = client.get_or_create_collection(name="university_documents")

def add_documents(chunks, embeddings, source_name="unknown", category="university"):
    ids = [f"{source_name}_{i}_{uuid.uuid4().hex[:8]}" for i in range(len(chunks))]
    metadatas = [
        {"source": source_name, "page": chunk["page"], "category": category}
        for chunk in chunks
    ]
    documents = [chunk["text"] for chunk in chunks]
    collection.add(ids=ids, documents=documents, embeddings=embeddings.tolist(), metadatas=metadatas)

def search_documents(query_embedding, n_results=3):
    return collection.query(query_embeddings=[query_embedding.tolist()], n_results=n_results)

def get_document_sources():
    results = collection.get(include=["metadatas"])
    sources = {}
    for metadata in results.get("metadatas", []):
        if not metadata:
            continue
        source = metadata.get("source", "Unknown")
        category = metadata.get("category", "Unknown")
        if source not in sources:
            sources[source] = {"category": category, "chunks": 0}
        sources[source]["chunks"] += 1
    return sources

def delete_document(source_name):
    results = collection.get(where={"source": source_name})
    ids = results.get("ids", [])
    if ids:
        collection.delete(ids=ids)
    return len(ids)

def get_document_count():
    return len(get_document_sources())

def search_knowledge_base(search_text="", category=None):
    results = collection.get(include=["documents", "metadatas"])
    matched = []
    search_text = search_text.lower().strip()

    for document, metadata in zip(results.get("documents", []), results.get("metadatas", [])):
        if not metadata:
            continue
        document_category = metadata.get("category", "Unknown")
        if category and category != "All" and document_category.lower() != category.lower():
            continue
        searchable = document.lower() + " " + metadata.get("source", "").lower()
        if search_text and search_text not in searchable:
            continue
        matched.append({
            "text": document,
            "source": metadata.get("source", "Unknown"),
            "page": metadata.get("page", "Unknown"),
            "category": document_category
        })
    return matched
