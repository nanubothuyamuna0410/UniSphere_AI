from pypdf import PdfReader

def load_pdf(file_path):
    reader = PdfReader(file_path)
    pages = []
    for page_number, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text()
        if page_text:
            pages.append({"page": page_number, "text": page_text})
    return pages

def create_chunks(pages, chunk_size=500):
    chunks = []
    for page in pages:
        text = page["text"]
        for i in range(0, len(text), chunk_size):
            chunks.append({"text": text[i:i + chunk_size], "page": page["page"]})
    return chunks
