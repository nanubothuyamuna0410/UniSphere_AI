import streamlit as st
import os
from services.embeddings import create_embeddings
from services.vector_score import search_documents, search_knowledge_base
from services.llm import generate_answer
from services.voice_input import listen_to_voice
from services.voice_output import speak_text

st.set_page_config(page_title="UniSphere AI - Student", page_icon="🎓", layout="wide")

css_path = os.path.join("assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

if not st.session_state.get("logged_in"):
    st.error("Please login first."); st.stop()
if st.session_state.get("role") != "student":
    st.error("Student access only."); st.stop()

if "messages" not in st.session_state: st.session_state.messages = []
if "quick_question" not in st.session_state: st.session_state.quick_question = None
if "voice_question" not in st.session_state: st.session_state.voice_question = None

with st.sidebar:
    st.title("🎓 UniSphere AI")
    st.caption("University Information Assistant")
    st.divider()
    st.write(f"👤 **{st.session_state.get('username', 'Student')}**")
    st.caption("Student")
    st.divider()
    st.subheader("🧭 Quick Access")

    quick_items = {
        "📚 Syllabus": "What information is available about the syllabus?",
        "📝 Examinations": "What information is available about examinations?",
        "📅 Academic Calendar": "What information is available about the academic calendar?",
        "💰 Fees": "What information is available about fees?",
        "🏠 Hostel": "What information is available about hostel facilities?",
        "💼 Placements": "What information is available about placements?",
        "📖 Library": "What information is available about the university library?"
    }
    for label, q in quick_items.items():
        if st.button(label, use_container_width=True):
            st.session_state.quick_question = q

    st.divider()
    st.subheader("⚙️ Chat")
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.session_state.quick_question = None
        st.session_state.voice_question = None
        st.rerun()
    if st.button("🚪 Logout", use_container_width=True):
        st.session_state.clear()
        st.switch_page("pages/login.py")

st.title("👋 Welcome to UniSphere AI")
st.write("Your intelligent university information assistant.")
st.caption("Ask questions about academics, examinations, hostel, fees, placements, library and more.")
st.divider()

a,b,c = st.columns(3)
with a: st.success("🟢 AI Assistant Online")
with b: st.info("🔍 RAG Knowledge Search")
with c: st.info("🧠 Llama 3.2")

st.divider()
st.subheader("⚡ Quick Questions")
a,b,c = st.columns(3)
with a:
    if st.button("🕘 College Timings", use_container_width=True):
        st.session_state.quick_question = "What are the college timings?"
with b:
    if st.button("📝 Exam Information", use_container_width=True):
        st.session_state.quick_question = "What information is available about examinations?"
with c:
    if st.button("📚 University Information", use_container_width=True):
        st.session_state.quick_question = "Give me important information about the university."

st.subheader("🗂️ Explore University Information")
a,b,c,d = st.columns(4)
with a:
    if st.button("🎓 Academics", use_container_width=True):
        st.session_state.quick_question = "What academic information is available?"
with b:
    if st.button("🏫 Campus", use_container_width=True):
        st.session_state.quick_question = "What information is available about the campus and university facilities?"
with c:
    if st.button("📖 Library", use_container_width=True):
        st.session_state.quick_question = "What information does the university library provide?"
with d:
    if st.button("👨‍🎓 Student Services", use_container_width=True):
        st.session_state.quick_question = "What student support services are available?"

st.divider()
st.subheader("🔎 Explore Knowledge Base")
a,b = st.columns([2,1])
with a:
    knowledge_search = st.text_input("🔍 Search university information", placeholder="Example: library, hostel, examinations...")
with b:
    knowledge_category = st.selectbox("🏷️ Category", [
        "All","University","Syllabus","Regulations","Examinations",
        "Academic Calendar","Fees","Hostel","Placements","Contacts"
    ])

if st.button("🔎 Search Knowledge Base", use_container_width=True):
    search_results = search_knowledge_base(knowledge_search, knowledge_category)
    if search_results:
        st.success(f"Found {len(search_results)} matching result(s).")
        for index, result in enumerate(search_results[:10], start=1):
            with st.expander(f"📄 Result {index} — {result['source']}"):
                st.write(f"📖 **Page:** {result['page']}")
                st.write(f"🏷️ **Category:** {result['category']}")
                st.write(result["text"])
    else:
        st.warning("No matching information found in the knowledge base.")

st.divider()
st.subheader("🎤 Voice Assistant")
if st.button("🎤 Speak"):
    with st.spinner("🎧 Listening..."):
        voice_question = listen_to_voice()
    if voice_question:
        st.session_state.voice_question = voice_question
        st.success(f"You said: **{voice_question}**")
    else:
        st.warning("Sorry, I could not understand your voice.")

typed_question = st.chat_input("Ask anything about your university...")
question = typed_question or st.session_state.get("voice_question") or st.session_state.get("quick_question")

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])
        if message["role"] == "assistant" and message.get("sources"):
            with st.expander("📚 View Sources"):
                for i, document in enumerate(message["sources"]):
                    st.write(f"### 📚 Source {i+1}")
                    metadata = message.get("metadatas", [])[i] if i < len(message.get("metadatas", [])) else {}
                    st.write(f"📄 **File:** {metadata.get('source','Unknown')}")
                    st.write(f"📖 **Page:** {metadata.get('page','Unknown')}")
                    st.write(f"🏷️ **Category:** {metadata.get('category','Unknown')}")
                    st.caption(document)
                    st.divider()

if question:
    st.session_state.quick_question = None
    st.session_state.voice_question = None
    st.session_state.messages.append({"role":"user","content":question})

    with st.chat_message("user"):
        st.write(question)

    with st.chat_message("assistant"):
        with st.spinner("🔍 Searching university knowledge..."):
            question_embedding = create_embeddings([question])[0]
            results = search_documents(question_embedding, n_results=3)
            documents = results.get("documents",[[]])[0]
            metadatas = results.get("metadatas",[[]])[0]

        with st.spinner("🤖 Generating answer..."):
            answer = generate_answer(question, "\n\n".join(documents))

        st.write(answer)

        if documents:
            st.success("🟢 Grounded answer — generated using university documents.")
        else:
            st.warning("🟡 No relevant university document was retrieved.")

        with st.expander("📚 View Sources"):
            if documents:
                for i, document in enumerate(documents):
                    st.write(f"### 📚 Source {i+1}")
                    metadata = metadatas[i] if i < len(metadatas) else {}
                    st.write(f"📄 **File:** {metadata.get('source','Unknown')}")
                    st.write(f"📖 **Page:** {metadata.get('page','Unknown')}")
                    st.write(f"🏷️ **Category:** {metadata.get('category','Unknown')}")
                    st.caption(document)
                    st.divider()
            else:
                st.write("No source documents were retrieved.")

        if st.button("🔊 Read Answer", key=f"read_{len(st.session_state.messages)}"):
            with st.spinner("🔊 Reading answer..."):
                speak_text(answer)

    st.session_state.messages.append({
        "role":"assistant",
        "content":answer,
        "sources":documents,
        "metadatas":metadatas
    })
