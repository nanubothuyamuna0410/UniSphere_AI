import streamlit as st
import os
from auth import login

st.set_page_config(page_title="UniSphere AI - Login", page_icon="🎓", layout="centered", initial_sidebar_state="collapsed")

css_path = os.path.join("assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.markdown("# 🎓")
st.title("UniSphere AI")
st.caption("Your Intelligent University Information Assistant")
st.divider()
st.subheader("🔐 Welcome Back")
st.write("Sign in to access your university AI assistant.")

username = st.text_input("Username", placeholder="Enter your username")
password = st.text_input("Password", type="password", placeholder="Enter your password")

if st.button("🚀 Login to UniSphere AI", use_container_width=True):
    if not username or not password:
        st.warning("Please enter your username and password.")
    else:
        role = login(username, password)
        if role:
            st.session_state["logged_in"] = True
            st.session_state["role"] = role
            st.session_state["username"] = username
            st.success("Login successful!")
            st.switch_page("pages/student.py" if role == "student" else "pages/admin.py")
        else:
            st.error("❌ Invalid username or password.")

st.divider()
st.write("### ✨ UniSphere AI Features")
c1, c2 = st.columns(2)
with c1:
    st.info("🤖 AI University Assistant")
    st.info("📚 RAG Knowledge Base")
with c2:
    st.info("🎤 Voice Assistant")
    st.info("📄 Smart Document Search")
with st.expander("🧪 Demo Credentials"):
    st.write("👤 Student: **student / student123**")
    st.write("🔐 Admin: **admin / admin123**")
st.caption("UniSphere AI • RAG + ChromaDB + Llama 3.2")
