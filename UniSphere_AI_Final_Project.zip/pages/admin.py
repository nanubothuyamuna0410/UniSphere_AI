import streamlit as st
import os
from services.documents_loader import load_pdf, create_chunks
from services.embeddings import create_embeddings
from services.vector_score import add_documents, get_document_sources, delete_document, get_document_count

st.set_page_config(page_title="UniSphere AI - Admin", page_icon="🔐", layout="wide")

css_path = os.path.join("assets", "style.css")
if os.path.exists(css_path):
    with open(css_path, encoding="utf-8") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

if not st.session_state.get("logged_in"):
    st.error("Please login first.")
    st.stop()
if st.session_state.get("role") != "admin":
    st.error("Admin access only.")
    st.stop()

with st.sidebar:
    st.title("🎓 UniSphere AI")
    st.caption("Admin Console")
    st.divider()
    st.write(f"🔐 **{st.session_state.get('username', 'Admin')}**")
    st.caption("Administrator")
    st.divider()
    st.subheader("🧭 Administration")
    st.button("📊 Dashboard", use_container_width=True)
    st.button("📄 Upload Document", use_container_width=True)
    st.button("📚 Knowledge Base", use_container_width=True)
    st.divider()
    if st.button("🚪 Logout", use_container_width=True):
        st.session_state.clear()
        st.switch_page("pages/login.py")

st.title("🔐 UniSphere AI")
st.subheader("Admin Dashboard")
st.write("Manage university documents and update the AI knowledge base.")
st.divider()

st.subheader("📊 System Overview")
c1, c2, c3, c4 = st.columns(4)
with c1: st.metric("📄 Documents", get_document_count())
with c2: st.metric("🧠 AI Model", "Llama 3.2")
with c3: st.metric("🔍 Vector Database", "ChromaDB")
with c4: st.metric("⚡ RAG Status", "Enabled")

st.divider()
st.subheader("📤 Upload University Document")
st.write("Upload a PDF to automatically add it to the AI knowledge base.")
uploaded_file = st.file_uploader("Choose a PDF document", type=["pdf"])
category = st.selectbox("🏷️ Select Document Category", [
    "University","Syllabus","Regulations","Examinations","Academic Calendar",
    "Fees","Hostel","Placements","Contacts"
])

if uploaded_file:
    st.info(f"📄 Selected document: {uploaded_file.name}")
    st.write(f"🏷️ Category: **{category}**")

    if st.button("🚀 Add to Knowledge Base", use_container_width=True):
        folder = os.path.join("data", category.lower().replace(" ", "_"))
        os.makedirs(folder, exist_ok=True)
        file_path = os.path.join(folder, uploaded_file.name)

        with open(file_path, "wb") as file:
            file.write(uploaded_file.getbuffer())

        try:
            with st.spinner("📖 Reading PDF..."):
                pages = load_pdf(file_path)
            with st.spinner("✂️ Creating text chunks..."):
                chunks = create_chunks(pages)
            with st.spinner("🧠 Creating embeddings..."):
                embeddings = create_embeddings(chunks)
            with st.spinner("🔍 Updating ChromaDB..."):
                add_documents(chunks, embeddings, uploaded_file.name, category)

            st.success("✅ Document successfully added to the AI knowledge base!")
            a, b, c = st.columns(3)
            with a: st.metric("📖 Pages", len(pages))
            with b: st.metric("✂️ Chunks", len(chunks))
            with c: st.metric("🏷️ Category", category)
            st.success("🤖 Students can now ask questions from this document.")
        except Exception as e:
            st.error(f"❌ Document processing failed: {e}")

st.divider()
st.subheader("📚 Knowledge Base")
sources = get_document_sources()

if not sources:
    st.info("📭 No documents found in the knowledge base.")
else:
    st.write(f"**{len(sources)} document(s) available**")
    for index, (source, details) in enumerate(sources.items(), start=1):
        st.markdown(f"### 📄 {index}. {source}")
        a, b, c = st.columns([2, 2, 1])
        with a: st.write(f"🏷️ **Category:** {details['category']}")
        with b: st.write(f"🧩 **Chunks:** {details['chunks']}")
        with c:
            if st.button("🗑️ Delete", key=f"delete_{index}_{source}"):
                deleted_chunks = delete_document(source)
                deleted_file = False
                for r, _, fs in os.walk("data"):
                    if source in fs:
                        try:
                            os.remove(os.path.join(r, source))
                            deleted_file = True
                        except Exception as e:
                            st.error(f"Could not delete file: {e}")
                if deleted_chunks > 0 or deleted_file:
                    st.success(f"✅ {source} deleted successfully.")
                else:
                    st.warning("Document could not be found.")
                st.rerun()
        st.divider()

st.subheader("🧠 RAG Pipeline")
a,b,c,d,e = st.columns(5)
with a: st.info("📄 PDF")
with b: st.info("📖 Extract")
with c: st.info("✂️ Chunk")
with d: st.info("🧠 Embed")
with e: st.info("🔍 ChromaDB")
st.divider()
st.subheader("📚 Knowledge Categories")
a,b,c = st.columns(3)
with a:
    st.write("🎓 **University**"); st.caption("General university information")
    st.write("📚 **Syllabus**"); st.caption("Courses and syllabus information")
    st.write("📝 **Examinations**"); st.caption("Examination-related information")
with b:
    st.write("📜 **Regulations**"); st.caption("University rules and regulations")
    st.write("📅 **Academic Calendar**"); st.caption("Academic schedules and dates")
    st.write("💰 **Fees**"); st.caption("Fee-related information")
with c:
    st.write("🏠 **Hostel**"); st.caption("Hostel facilities and rules")
    st.write("💼 **Placements**"); st.caption("Placement-related information")
    st.write("📞 **Contacts**"); st.caption("Important university contacts")
st.divider()
st.caption("UniSphere AI • Admin Console • RAG + ChromaDB + Llama 3.2")
