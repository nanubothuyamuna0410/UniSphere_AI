Upload official university PDFs into the appropriate category folder or use the Admin Dashboard.
