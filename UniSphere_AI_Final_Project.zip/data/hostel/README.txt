Place official hostel PDFs here.
