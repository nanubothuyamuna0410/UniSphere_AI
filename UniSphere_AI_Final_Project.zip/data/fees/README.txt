Place official fees PDFs here.
