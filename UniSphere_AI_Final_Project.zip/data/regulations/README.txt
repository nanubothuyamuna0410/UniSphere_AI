Place official regulations PDFs here.
